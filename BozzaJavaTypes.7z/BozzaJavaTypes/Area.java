package univaq.se.sensors.types;

import java.io.Serializable;
import java.util.HashMap;

public class Area implements Serializable {

	private static final long serialVersionUID = 1L;
	protected String areaCode;
	protected HashMap<String, Edificio> mappaArea;
	
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public HashMap<String, Edificio> getMappaArea() {
		return mappaArea;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
