package univaq.se.sensors.types;

import java.io.Serializable;
import java.util.HashMap;

public class Edificio implements Serializable{

	private static final long serialVersionUID = 1L;
	protected String buildingCode;
	protected HashMap<String, Stanza> mappaEdificio;
	
	public String getBuildingCode() {
		return buildingCode;
	}
	public void setBuildingCode(String buildingCode) {
		this.buildingCode = buildingCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public HashMap<String, Stanza> getMappaEdificio() {
		return mappaEdificio;
	}

}
