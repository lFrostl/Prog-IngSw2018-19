package univaq.se.sensors.types;

import java.io.Serializable;
import java.util.List;

public class Sensore implements Serializable{

	private static final long serialVersionUID = 1L;
	protected String sensorCode;
	protected Tipo sensorType;
	protected Double valMax;
	protected String unitaMisura;
	protected List<Segnale> storicoSensore;
	
	public String getSensorCode() {
		return sensorCode;
	}
	public void setSensorCode(String sensorCode) {
		this.sensorCode = sensorCode;
	}
	public Tipo getSensorType() {
		return sensorType;
	}
	public void setSensorType(Tipo sensorType) {
		this.sensorType = sensorType;
	}
	public double getValMax() {
		return valMax;
	}
	public void setValMax(double valMax) {
		this.valMax = valMax;
	}
	public String getUnitaMisura() {
		return unitaMisura;
	}
	public void setUnitaMisura(String unitaMisura) {
		this.unitaMisura = unitaMisura;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<Segnale> getStoricoSensore() {
		return storicoSensore;
	}
		
}
