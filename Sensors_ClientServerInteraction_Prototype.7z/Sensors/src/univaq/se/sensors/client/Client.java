package univaq.se.sensors.client;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import univaq.se.sensors.types.Edificio;
import univaq.se.sensors.types.Stanza;

// Client class 
public class Client {
	public static void main(String[] args) throws IOException {
		try {
			Scanner scn = new Scanner(System.in);

			// getting localhost ip
			String ip = "127.0.0.1";

			// establish the connection with server port 5056
			Socket s = new Socket(ip, 7776);

			// obtaining input and out streams
			DataOutputStream dos = new DataOutputStream(s.getOutputStream());
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());

			// the following loop contains the excange
			// of the information between client and server
			// and the client authentication process

			boolean x = true;
			while (x == true) {

				System.out.println("Inserire Username: ");
				String user = scn.nextLine();
				dos.writeUTF(user);
				dos.flush();

				boolean b = false;
				while (true) {

					b = ois.readBoolean();
					if (b) {
						while (true) {
							System.out.println(ois.readUTF());
							String tosend = scn.nextLine();
							dos.writeUTF(tosend);
							dos.flush();


							// If client sends Esci,close this connection
							// and then break from the while loop
							if (tosend.equals("Esci")) {
								System.out.println("Connessione in chiusura : " + s);
								s.close();
								System.out.println("Connessione chiusa");
								x = false;
								break;
							}

							try {	
								Object o = ois.readObject();

								if(o instanceof Edificio){
									Edificio received = (Edificio) o;
									System.out.println(received.toString());
								}
								else if(o instanceof Stanza){
									Stanza received = (Stanza) o;
									System.out.println(received.toString());
								}
							}catch(OptionalDataException ode) {
								
								System.out.println("Input non valido");
							} 
						}
					} else {
						System.out.println("Username o password errati!");
					}

				}
			}

			// closing resources
			scn.close();
			dos.close();
			ois.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}