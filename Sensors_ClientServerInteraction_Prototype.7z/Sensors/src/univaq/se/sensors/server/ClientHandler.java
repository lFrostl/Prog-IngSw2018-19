package univaq.se.sensors.server;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import univaq.se.sensors.types.Edificio;
import univaq.se.sensors.types.Sensore;
import univaq.se.sensors.types.Stanza;
import univaq.se.sensors.types.Tipo; 

class ClientHandler extends Thread  
{ 
    final DataInputStream dis; 
    final ObjectOutputStream oos;
    final Socket s; 
      
  
    // Constructor 
    public ClientHandler(Socket s, DataInputStream dis, ObjectOutputStream oos)  
    { 
        this.s = s; 
        this.dis = dis; 
    	this.oos = oos;
    } 
  
    @Override
    public void run()  
    { 
        String received; 
    	
    	String username;
    	boolean x = false;

		try {
			username = dis.readUTF();
			System.out.println("Server: username is " + username);
	    	boolean result = authentication(username);
	    	if(result == true) {
		    	x=true;	
		    	oos.writeBoolean(true);
		    	oos.flush();
	    	}
	    	else {
	    		x=false;
		    	oos.writeBoolean(false);
		    	oos.flush();
	    	}
		} catch (IOException e1) {
			e1.printStackTrace();
		}

        try { 

	        while (x == true)  
	        { 
                // Ask user what he wants 
                oos.writeUTF("Dato richiesto?[Edificio | Stanza]..\n"+ 
                            "Scrivi Esci per terminare la connessione.");
		    	oos.flush();
		    	                  
                // receive the answer from client 
                received = dis.readUTF(); 
                
                  
                if(received.equals("Esci")) 
                {  
                    System.out.println("Client " + this.s + " sends exit..."); 
                    System.out.println("Closing this connection."); 
                    this.s.close(); 
                    System.out.println("Connection closed"); 
                    break; 
                } 
                  
                Sensore sens = new Sensore();
                sens.setSensorCode("12");
                sens.setSensorType(Tipo.TEMPERATURA);
                sens.setUnitaMisura("Celsius");
                sens.setValMax(30);
                Stanza stanza = new Stanza(); 
                stanza.setRoomCode("12");
                stanza.getMappaStanza().put("12", sens);

                  
                switch (received) { 
                  
                    case "Edificio" : 
                    	Edificio edificio = new Edificio();
                    	edificio.setBuildingCode("1");
                    	edificio.getMappaEdificio().put("12", stanza);
                        oos.writeObject(edificio); 
        		    	oos.flush();
                        break; 
                          
                    case "Stanza" : 
                        oos.writeObject(stanza);
        		    	oos.flush();
                        break; 
                          
                    default: 
                        oos.writeUTF("Invalid input"); 
        		    	oos.flush();
                        break; 
                } 

            } 
        } catch (IOException e) { 
            e.printStackTrace(); 
        } 
          
        try
        { 
            // closing resources 
        	this.s.close();
            this.dis.close(); 
            this.oos.close(); 
            
              
        }catch(IOException e){ 
            e.printStackTrace(); 
        } 
    } 
    
    public boolean authentication(String s) {
    	
    	if(s.equals("root")) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
} 
