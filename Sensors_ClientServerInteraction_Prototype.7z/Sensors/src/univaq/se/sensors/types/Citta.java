package univaq.se.sensors.types;

import java.io.Serializable;
import java.util.HashMap;

public class Citta implements Serializable {

	private static final long serialVersionUID = 1L;
	protected String cityCode;
	protected HashMap<String, Area> mappaCitta;
	
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public HashMap<String, Area> getMappaCitta() {
		return mappaCitta;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
