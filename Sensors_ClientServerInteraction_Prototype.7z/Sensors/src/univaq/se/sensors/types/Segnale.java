package univaq.se.sensors.types;

import java.io.Serializable;
import java.sql.Timestamp;

public class Segnale implements Serializable{

	private static final long serialVersionUID = 1L;
	protected String sensorCode;
	private Double valore;
	private Timestamp timestamp;
	
	public double getValore() {
		return valore;
	}
	public void setValore(double valore) {
		this.valore = valore;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public String getSensorCode() {
		return sensorCode;
	}
	public void setSensorCode(String sensorCode) {
		this.sensorCode = sensorCode;
	}
	
	@Override
	public String toString() {
		return "Segnale [sensorCode=" + sensorCode + ", valore=" + valore + ", timestamp=" + timestamp + "]";
	}

}
