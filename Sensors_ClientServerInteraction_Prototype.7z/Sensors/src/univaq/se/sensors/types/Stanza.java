package univaq.se.sensors.types;

import java.io.Serializable;
import java.util.HashMap;

public class Stanza implements Serializable{

	private static final long serialVersionUID = 1L;
	protected String roomCode;
	protected HashMap<String, Sensore> mappaStanza = new HashMap<String, Sensore>();
	
	public String getRoomCode() {
		return roomCode;
	}
	public void setRoomCode(String roomCode) {
		this.roomCode = roomCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public HashMap<String, Sensore> getMappaStanza() {
		return mappaStanza;
	}
	
	@Override
	public String toString() {
		return "Stanza [roomCode=" + roomCode + ", mappaStanza=" + mappaStanza + "]";
	}

}
