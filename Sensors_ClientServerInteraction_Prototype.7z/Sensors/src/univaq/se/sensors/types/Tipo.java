package univaq.se.sensors.types;

public enum Tipo {

    TEMPERATURA(0),
    FUMO(1),
    CO2(2),
    UMIDITA(3),
    RADON(4);
    private Integer code;

    private Tipo(Integer code) {
        this.code = code;
    }
}
